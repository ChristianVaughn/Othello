Andy M. and Christian V. Othello
 
 Import Database
    Go to phpmyadmin, and click import and select the AmCvDatabase.sql file
    database and required tables will be created. 

Requires server to be localhost, username to be root, and password to be empty.

'DB_SERVER', 'localhost'
'DB_USERNAME', 'root'
'DB_PASSWORD', ''